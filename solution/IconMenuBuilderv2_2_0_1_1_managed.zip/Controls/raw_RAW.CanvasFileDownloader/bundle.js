var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad=function(e){var t={};function n(o){if(t[o])return t[o].exports;var r=t[o]={i:o,l:!1,exports:{}};return e[o].call(r.exports,r,r.exports,n),r.l=!0,r.exports}return n.m=e,n.c=t,n.d=function(e,t,o){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:o})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var o=Object.create(null);if(n.r(o),Object.defineProperty(o,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var r in e)n.d(o,r,function(t){return e[t]}.bind(null,r));return o},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=0)}([
/*!***************************************!*\
  !*** ./CanvasFileDownloader/index.ts ***!
  \***************************************/
/*! no static exports found */
/*! all exports used */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.CanvasFileDownloader=void 0;var o=function(){function e(){}return e.prototype.init=function(e,t,n,o){this._notifyOutputChanged=t,this._container=o},e.prototype.updateView=function(e){var t,n,o=e.parameters;if(null===(t=o.download)||void 0===t?void 0:t.raw){var r=document.createElement("a");r.href=(null===(n=o.fileContents.raw)||void 0===n?void 0:n.startsWith("data:"))?o.fileContents.raw:"data:"+o.fileMIMEType.raw+";base64,"+o.fileContents.raw,r.download=o.fileName.raw||"",document.body.appendChild(r),r.click(),document.body.removeChild(r),this._notifyOutputChanged()}},e.prototype.getOutputs=function(){return{download:!1}},e.prototype.destroy=function(){},e}();t.CanvasFileDownloader=o}]);
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('RAW.CanvasFileDownloader', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CanvasFileDownloader);
} else {
	var RAW = RAW || {};
	RAW.CanvasFileDownloader = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CanvasFileDownloader;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}